---
name: Haute Nude Couture
colors:
  surface: '#fcf9f7'
  surface-dim: '#dcd9d8'
  surface-bright: '#fcf9f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f1'
  surface-container: '#f0edeb'
  surface-container-high: '#eae8e6'
  surface-container-highest: '#e5e2e0'
  on-surface: '#1b1c1b'
  on-surface-variant: '#504440'
  inverse-surface: '#30302f'
  inverse-on-surface: '#f3f0ee'
  outline: '#82746f'
  outline-variant: '#d3c3bd'
  surface-tint: '#74584d'
  primary: '#74584d'
  on-primary: '#ffffff'
  primary-container: '#d8b4a6'
  on-primary-container: '#5f453a'
  inverse-primary: '#e3bfb0'
  secondary: '#725b38'
  on-secondary: '#ffffff'
  secondary-container: '#fedeb2'
  on-secondary-container: '#78603e'
  tertiary: '#665c59'
  on-tertiary: '#ffffff'
  tertiary-container: '#c5b9b4'
  on-tertiary-container: '#524946'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbcd'
  primary-fixed-dim: '#e3bfb0'
  on-primary-fixed: '#2a170e'
  on-primary-fixed-variant: '#5b4136'
  secondary-fixed: '#fedeb2'
  secondary-fixed-dim: '#e0c298'
  on-secondary-fixed: '#281800'
  on-secondary-fixed-variant: '#584323'
  tertiary-fixed: '#ede0db'
  tertiary-fixed-dim: '#d1c4bf'
  on-tertiary-fixed: '#211a17'
  on-tertiary-fixed-variant: '#4d4542'
  background: '#fcf9f7'
  on-background: '#1b1c1b'
  surface-variant: '#e5e2e0'
typography:
  display-xl:
    fontFamily: Bodoni Moda
    fontSize: 4.5rem
    fontWeight: '400'
    lineHeight: 5rem
    letterSpacing: -0.02em
  display-xl-mobile:
    fontFamily: Bodoni Moda
    fontSize: 2.75rem
    fontWeight: '400'
    lineHeight: 3.25rem
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Bodoni Moda
    fontSize: 3rem
    fontWeight: '400'
    lineHeight: 3.5rem
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 2rem
    fontWeight: '400'
    lineHeight: 2.5rem
    letterSpacing: 0em
  headline-md:
    fontFamily: Bodoni Moda
    fontSize: 2rem
    fontWeight: '400'
    lineHeight: 2.5rem
    letterSpacing: 0em
  headline-sm:
    fontFamily: Bodoni Moda
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: 2rem
    letterSpacing: 0.01em
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.625rem
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.875rem
    letterSpacing: 0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.9375rem
    fontWeight: '400'
    lineHeight: 1.625rem
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.375rem
    letterSpacing: 0.02em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.18em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 0.875rem
    letterSpacing: 0.22em
spacing:
  gutter: 2rem
  gutter-mobile: 1rem
  margin: 4rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 2rem
  space-xl: 3.5rem
  space-2xl: 6rem
---

## Brand & Style

This design system establishes an ultra-refined, editorial visual language rooted in haute couture cosmetic ateliers and prestigious luxury fashion houses. It bridges tactile tactile softness with unyielding architectural discipline, projecting an aura of quiet confidence, timeless artistry, and exquisite curation.

### Brand Atmosphere & Tone
- **Atmosphere**: Sensual yet structured, calm, pristine, and aspirational.
- **Key Influence**: Parisian runway programs, heavy-weight bond stationery, powdered nudes, and the clinical precision of luxury skin formulation.
- **Design Style**: High-fashion Minimalist Editorial. Pure rectilinear silhouettes with zero corner radii create gallery-grade frames for imagery, while powdered flesh tones provide warmth and intimacy.

## Colors

The palette mimics raw silk, powdered talc, warm alabaster, and gilded bronze against jet obsidian.

- **Primary (`#D8B4A6`)**: Powdered Nude Blush. Evokes natural flush, porcelain skin undertones, and warm terracotta clay. Used for focal highlights, delicate tint washes, and primary accent structures.
- **Secondary (`#C5A880`)**: Muted Champagne Bronze. A quiet metallic note that delivers an impression of heirloom hardware, gilded edges, and reflective liquid illumination.
- **Tertiary (`#2B2421`)**: Espresso Noir. Softened black with rich umber undertones, preventing harsh clinical contrast while sustaining editorial authority for type, hairline borders, and primary interactive elements.
- **Neutral (`#FAF7F5`)**: Alabaster Cream. A warm, non-glare canvas base reminiscent of archival handmade paper, serving as the foundational surface backdrop.

### Functional Nuances
- **Surface Elevation**: `#FFFFFF` acts as elevated product stage cards over the `#FAF7F5` base field.
- **Borders & Rules**: 1px solids rendered in rgba values of `#2B2421` at 10%–18% opacity, keeping partitions as fine as gossamer thread.

## Typography

The typographic system creates an interplay between historic haute-editorial grandeur and technical modernist legibility.

- **Headlines (`Bodoni Moda`)**: Dramatic high-contrast serifs with razor-thin serifs and monumental vertical stress. Evokes high-end fragrance flacons, mastheads, and couture monograms.
- **Body & Labels (`Plus Jakarta Sans`)**: Clean, contemporary sans-serif providing crystal-clear readability for ingredient panels, formulation notes, pricing, and transactional journeys.
- **Casing & Spacing Rules**: Labels and navigation prompts always appear in strict uppercase with expanded tracking (`0.18em` to `0.22em`), underscoring atelier precision.

## Layout & Spacing

Space is treated as an active luxury material rather than void. Generous margins and breathing rooms isolate editorial artifacts, signaling confidence and calm restraint.

### Grid & Composition
- **Desktop (12 Columns)**: 4rem page margins with 2rem column gutters. Maximum content boundaries capped at `1440px` for optimal visual balance.
- **Tablet (8 Columns)**: 2.5rem margins with 1.5rem gutters.
- **Mobile (4 Columns)**: 1.25rem outer boundary margins with 1rem gutters.
- **Asymmetric Offsets**: Lookbooks and campaign features utilize deliberate offset compositions (e.g., imagery spanning columns 1–7 with narrative offset spanning columns 9–12).

## Elevation & Depth

This system intentionally eliminates blurred drop shadows, ambient fuzz, and heavy material dimensionality. Depth is achieved via **tonal architecture** and **crisp hairline spatial separation**.

1. **Planar Shifts**: Depth is established by layering `#FFFFFF` panels on top of the `#FAF7F5` foundation.
2. **Hairline Delimitation**: Sections, trays, and modal drawers are separated by razor-sharp `1px` borders (`#2B2421` at 12% opacity), evoking fine card stock trimming.
3. **Translucent Overlays**: Sticky headers and floating drawers utilize `#FAF7F5` with 88% opacity paired with `backdrop-filter: blur(12px)`.
4. **Active Modals**: Full-screen tint overlays utilize `#2B2421` at a soft 35% opacity to focus absolute attention onto the sharply framed modal container.

## Shapes

The shape philosophy is strictly architectural: **`roundedness: 0` (Sharp)**. Every interface element—from buttons and imagery viewports to notification toasts, inputs, and swatch tiles—features immaculate, unsoftened 90-degree right angles.

- **Concept**: Reflects clean cut packaging, architectural boutique flagship interiors, and pristine magazine flatlays.
- **Prohibitions**: Rounded corners, pill buttons, and circular status markers are strictly avoided to preserve the editorial haute-couture silhouette.

## Components

### Buttons
- **Primary**: Solid `#2B2421` background, `#FAF7F5` text, 0px border radius, uppercase typography (`label-lg`), minimum height `52px`. On hover: smooth transition to `#D8B4A6` with `#2B2421` text.
- **Secondary / Outline**: Transparent background, 1px solid border in `#2B2421`, `#2B2421` text. Hover transitions to solid `#2B2421` fill with `#FAF7F5` text.
- **Tertiary (Text)**: Transparent, `#2B2421` text, subtle 1px border underline positioned 4px beneath the baseline that extends across full label width on hover.

### Product & Editorial Cards
- **Structure**: Rectangular 0px cards set on `#FFFFFF`. Aspect ratio 3:4 for portrait beauty assets or 1:1 for formulation packs.
- **Meta Hierarchy**: Subdued category eyebrow in uppercase `label-sm`, title in `Bodoni Moda` (`headline-sm`), followed by discrete price formatting in `Plus Jakarta Sans`.
- **Interactions**: Subtle zoom (1.02x transform over 600ms cubic bezier) within strict overflow-hidden bounds on hover; primary quick-add bar reveals from card footer.

### Input Fields & Selectors
- **Form Fields**: Clean underline-only or full 1px hairline border containers. Height `48px`, background `#FFFFFF`, text `#2B2421`.
- **Focus State**: Hairline border darkens to solid `#2B2421` with zero drop shadow or focus ring glow.
- **Floating Labels**: Elegant transition from centered placeholder to `label-sm` positioned precisely above the field.

### Selection Controls (Checkboxes & Radios)
- **Checkboxes**: Pure square box (16px × 16px), 1px solid `#2B2421` border, 0px corner radius. Selected state displays an inner filled `#2B2421` square with 2px padding.
- **Radio Buttons**: Sharp square within square, honoring the strict 0-radius mandate.

### Swatches & Shade Selectors
- **Color Chips**: 24px × 24px square blocks displaying actual shade hues. Active state indicated by an external 1px `#2B2421` border separated by a 2px alabaster margin gap.

### Drawers & Trays (Cart & Navigation)
- **Cart Flyout**: Rigid right-docked panel spanning 420px desktop width, framed with a 1px left hairline border in `#2B2421` (12% opacity), completely flush to edge boundaries.